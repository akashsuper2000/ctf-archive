import kotlin.Metadata;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\030\0002\0020\001B\005¢\006\002\020\002J\006\020\005\032\0020\004R\016\020\003\032\0020\004XD¢\006\002\n\000¨\006\006"}, d2={"LPublicLibrary;", "", "()V", "flag", "", "getFlag", "public-library"})
public final class PublicLibrary { private final String flag = "bcactf{t4k3_4_j4v4_c7a55_789208694209642475}";
  
  @org.jetbrains.annotations.NotNull
  public final String getFlag() { return flag; }
  
  public PublicLibrary() {}
}
